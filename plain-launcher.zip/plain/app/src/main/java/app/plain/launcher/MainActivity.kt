package app.plain.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.ColorStateList
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Rect
import android.graphics.Typeface
import android.net.Uri
import android.os.CountDownTimer
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.Spannable
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import android.view.Gravity
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    data class App(val pkg: String, val label: String)

    private lateinit var prefs: SharedPreferences
    private lateinit var gd: GestureDetector
    private lateinit var root: FrameLayout
    private lateinit var favBox: LinearLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var listBox: LinearLayout
    private lateinit var scroll: ScrollView
    private var gate: FrameLayout? = null
    private var timer: CountDownTimer? = null
    private var apps = listOf<App>()
    private val handler = Handler(Looper.getMainLooper())
    private val tick = object : Runnable {
        override fun run() { updateClock(); handler.postDelayed(this, 15000) }
    }

    private val dark get() = prefs.getBoolean("dark", true)
    private val bg get() = if (dark) 0xFF1B1C1E.toInt() else 0xFFECEBE6.toInt()
    private val fg get() = if (dark) 0xFFECEBE6.toInt() else 0xFF1B1C1E.toInt()
    private val dim get() = if (dark) 0xFF8D8E91.toInt() else 0xFF6D6E72.toInt()
    private val accent get() = if (dark) 0xFFC9D6C2.toInt() else 0xFF3C5A3A.toInt()
    private val drawerOpen get() = drawer.visibility == View.VISIBLE

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun favs(): MutableList<String> =
        (prefs.getString("favs", "") ?: "").split(",").filter { it.isNotEmpty() }.toMutableList()
    private fun saveFavs(l: List<String>) = prefs.edit().putString("favs", l.joinToString(",")).apply()
    private fun mindful(): MutableSet<String> = HashSet(prefs.getStringSet("mindful", emptySet()) ?: emptySet())
    private fun delaySecs() = prefs.getInt("delay", 15)

    override fun onCreate(b: android.os.Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("plain", Context.MODE_PRIVATE)
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (gate != null) return false
                if (!drawerOpen && vy < -1200f) openDrawer()
                else if (drawerOpen && vy > 1200f && scroll.scrollY == 0) closeDrawer()
                return false
            }
            override fun onLongPress(e: MotionEvent) {
                if (gate != null || drawerOpen) return
                val r = Rect()
                favBox.getGlobalVisibleRect(r)
                if (!r.contains(e.rawX.toInt(), e.rawY.toInt())) settingsDialog()
            }
        })
        render()
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        gd.onTouchEvent(e)
        return super.dispatchTouchEvent(e)
    }

    override fun onResume() {
        super.onResume()
        loadApps(); refreshFavs(); fill()
        handler.post(tick)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(tick)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (gate != null) hideGate()
        closeDrawer()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (gate != null) hideGate() else if (drawerOpen) closeDrawer()
    }

    private fun tv(t: String, sp: Float, color: Int, light: Boolean = true) = TextView(this).apply {
        text = t; textSize = sp; setTextColor(color)
        typeface = Typeface.create(if (light) "sans-serif-light" else "sans-serif", Typeface.NORMAL)
    }

    private fun render() {
        window.statusBarColor = bg
        window.navigationBarColor = bg
        window.decorView.systemUiVisibility = if (dark) 0 else
            (View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR)
        root = FrameLayout(this).apply { setBackgroundColor(bg); fitsSystemWindows = true }

        val home = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(32), dp(40), dp(32), dp(24))
        }
        clock = tv("", 64f, fg).apply { letterSpacing = -0.03f }
        date = tv("", 15f, dim)
        favBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val all = tv("All apps", 14f, dim, false).apply {
            setPadding(0, dp(12), 0, dp(12)); setOnClickListener { openDrawer() }
        }
        val set = tv("Settings", 14f, dim, false).apply {
            setPadding(dp(16), dp(12), 0, dp(12)); setOnClickListener { settingsDialog() }
        }
        bar.addView(all, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        bar.addView(set)
        home.addView(clock); home.addView(date)
        home.addView(View(this), LinearLayout.LayoutParams(1, 0, 1f))
        home.addView(favBox)
        home.addView(bar)
        root.addView(home, ViewGroup.LayoutParams(-1, -1))

        drawer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(32), dp(24), dp(32), dp(16))
            visibility = View.GONE
        }
        search = EditText(this).apply {
            hint = "Search apps"; setHintTextColor(dim); setTextColor(fg); textSize = 18f
            setBackgroundColor(0); setSingleLine(true)
            setPadding(0, dp(12), 0, dp(12))
            imeOptions = EditorInfo.IME_ACTION_GO
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { fill() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
            setOnEditorActionListener { _, _, _ -> matches().firstOrNull()?.let { launch(it) }; true }
        }
        listBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll = ScrollView(this).apply { addView(listBox) }
        val close = tv("Close", 14f, dim, false).apply {
            setPadding(0, dp(12), 0, dp(12)); setOnClickListener { closeDrawer() }
        }
        drawer.addView(search); drawer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f)); drawer.addView(close)
        root.addView(drawer, ViewGroup.LayoutParams(-1, -1))
        setContentView(root)
        loadApps(); refreshFavs(); updateClock(); fill()
    }

    private fun updateClock() {
        val now = Date()
        val f = if (prefs.getBoolean("h24", false)) "HH:mm" else "h:mm"
        clock.text = SimpleDateFormat(f, Locale.getDefault()).format(now)
        date.text = SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now)
    }

    private fun loadApps() {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = packageManager.queryIntentActivities(i, 0)
            .map { App(it.activityInfo.packageName, it.loadLabel(packageManager).toString()) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun matches(): List<App> {
        val q = search.text.toString().trim().lowercase()
        return apps.filter { it.label.lowercase().contains(q) }
    }

    private fun row(a: App, sp: Float): TextView {
        val sb = SpannableStringBuilder(a.label)
        if (a.pkg in mindful()) {
            val s = sb.length
            sb.append("  mindful")
            sb.setSpan(RelativeSizeSpan(0.55f), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            sb.setSpan(ForegroundColorSpan(dim), s, sb.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return tv("", sp, fg).apply {
            text = sb
            setPadding(0, dp(10), 0, dp(10))
            setOnClickListener { launch(a) }
            setOnLongClickListener { menu(a); true }
        }
    }

    private fun refreshFavs() {
        favBox.removeAllViews()
        val list = favs().mapNotNull { p -> apps.find { it.pkg == p } }
        if (list.isEmpty()) favBox.addView(tv("Open All apps and long-press an app to pin it here.", 14f, dim))
        list.forEach { favBox.addView(row(it, 26f)) }
    }

    private fun fill() {
        listBox.removeAllViews()
        matches().forEach { listBox.addView(row(it, 20f)) }
        if (listBox.childCount == 0) listBox.addView(tv("No app matches that.", 14f, dim))
    }

    private fun openDrawer() {
        search.setText("")
        drawer.alpha = 0f; drawer.visibility = View.VISIBLE
        drawer.animate().alpha(1f).setDuration(160).start()
        search.requestFocus()
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .showSoftInput(search, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun closeDrawer() {
        if (!::drawer.isInitialized || !drawerOpen) return
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(search.windowToken, 0)
        drawer.visibility = View.GONE
        search.setText("")
    }

    private fun launch(a: App) {
        if (a.pkg in mindful() && delaySecs() > 0) showGate(a) else start(a)
    }

    private fun start(a: App) {
        val i = packageManager.getLaunchIntentForPackage(a.pkg)
        if (i != null) startActivity(i) else Toast.makeText(this, "Can’t open ${a.label}", Toast.LENGTH_SHORT).show()
        closeDrawer()
    }

    private fun showGate(a: App) {
        hideGate()
        val total = delaySecs() * 1000L
        val title = tv("Do you need this?", 28f, fg)
        val msg = tv("", 15f, dim).apply { setPadding(0, dp(8), 0, dp(28)) }
        val bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 1000
            progressTintList = ColorStateList.valueOf(accent)
            progressBackgroundTintList = ColorStateList.valueOf(dim)
        }
        val open = tv("Open", 17f, fg, false).apply {
            setPadding(0, dp(24), dp(32), dp(12)); alpha = 0.35f; isEnabled = false
            setOnClickListener { hideGate(); start(a) }
        }
        val back = tv("Go back", 17f, dim, false).apply {
            setPadding(0, dp(24), 0, dp(12)); setOnClickListener { hideGate() }
        }
        val btns = LinearLayout(this).apply { addView(open); addView(back) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(32), 0, dp(32), 0)
            addView(title); addView(msg); addView(bar); addView(btns)
        }
        gate = FrameLayout(this).apply {
            setBackgroundColor(bg); isClickable = true
            addView(col, FrameLayout.LayoutParams(-1, -1))
        }
        root.addView(gate, ViewGroup.LayoutParams(-1, -1))
        timer = object : CountDownTimer(total, 50) {
            override fun onTick(ms: Long) {
                bar.progress = (((total - ms) * 1000) / total).toInt()
                msg.text = "Take a breath. ${a.label} opens in ${(ms + 999) / 1000}s."
            }
            override fun onFinish() {
                bar.progress = 1000
                msg.text = "Still want ${a.label}? Open it on purpose."
                open.alpha = 1f; open.isEnabled = true
            }
        }.start()
    }

    private fun hideGate() {
        timer?.cancel(); timer = null
        gate?.let { root.removeView(it) }
        gate = null
    }

    private fun menu(a: App) {
        val fl = favs(); val m = mindful()
        val pinned = a.pkg in fl; val mind = a.pkg in m
        val items = arrayOf(
            if (pinned) "Unpin from home" else "Pin to home",
            if (mind) "Remove mindful delay" else "Add mindful delay",
            "App info", "Uninstall"
        )
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> {
                    if (pinned) fl.remove(a.pkg)
                    else if (fl.size >= 6) Toast.makeText(this, "Home holds 6 apps. Unpin one first.", Toast.LENGTH_SHORT).show()
                    else fl.add(a.pkg)
                    saveFavs(fl); refreshFavs()
                }
                1 -> {
                    if (mind) m.remove(a.pkg) else m.add(a.pkg)
                    prefs.edit().putStringSet("mindful", m).apply(); fill(); refreshFavs()
                }
                2 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                3 -> startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
            }
        }.show()
    }

    private fun settingsDialog() {
        val steps = listOf(0, 5, 10, 15, 30)
        val items = arrayOf(
            "Mindful delay: ${delaySecs()}s",
            "Clock: " + if (prefs.getBoolean("h24", false)) "24-hour" else "12-hour",
            "Theme: " + if (dark) "Dark" else "Light",
            "Make Plain the default home app"
        )
        AlertDialog.Builder(this).setTitle("Settings").setItems(items) { _, w ->
            when (w) {
                0 -> {
                    val n = steps[(steps.indexOf(delaySecs()) + 1) % steps.size]
                    prefs.edit().putInt("delay", n).apply(); settingsDialog()
                }
                1 -> { prefs.edit().putBoolean("h24", !prefs.getBoolean("h24", false)).apply(); updateClock(); settingsDialog() }
                2 -> { prefs.edit().putBoolean("dark", !dark).apply(); render() }
                3 -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            }
        }.show()
    }
}
